package com.taskmanagementsystem.taskmanagementsystem.controller;

public @interface Valid {
}
