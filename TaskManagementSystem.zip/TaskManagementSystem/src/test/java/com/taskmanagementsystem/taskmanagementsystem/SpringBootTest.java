package com.taskmanagementsystem.taskmanagementsystem;

public @interface SpringBootTest {
}
