package com.taskmanagementsystem.taskmanagementsystem.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    COMPLETED,
}
